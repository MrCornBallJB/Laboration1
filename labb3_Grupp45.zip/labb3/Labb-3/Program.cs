﻿using System.Xml.Serialization;

namespace Labb_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //interface
            Boolean KeepGoing= true;
            while (KeepGoing) {

            Console.WriteLine("Vad vill du göra?");
            Console.WriteLine("1: En lista över varje dag och temperatur \n" +
                "2: Den högsta temperaturen \n" +
                "3: Den lägsta temperaturen \n" +
                "4: Median temperaturen \n" +
                "5: Medeltemperaturen \n" +
                "6: Lista med temperaturena från minst till störst \n" +
                "7: Lista med temperaturena från störst till minst \n" +
                "8: Välj temperatur och får alla som är högre \n" +
                "9: Välj en dag och får föregående och dagen efter \n" +
                "10: Få den vanligaste temperaturen");


            //input där man väljer vad man vill göra
            int Choice = int.Parse(Console.ReadLine());

                switch (Choice)
                {
                    case 1:
                        Get_List();
                        break;

                    case 2:
                        Get_Highest();
                        break;

                    case 3:
                        Get_Lowest();
                        break;

                    case 4:
                        Get_Median();
                        break;

                    case 5:
                        Get_Medel();
                        break;

                    case 6:
                        Risinglist();
                        break;

                    case 7:
                        Fallinglist();
                        break;

                    case 8:
                        double usertemp = Convert.ToDouble(Console.ReadLine());
                        Choosetemp(usertemp);
                        break;

                    case 9:
                        int userday = int.Parse(Console.ReadLine());
                        Multiday(userday);
                        break;

                    case 10:
                        Get_Common();
                        break;
                }
            }


        }

        //lista med alla dagar och deras temperaturer
        static void Get_List()
        {
            //skapar ett objekt för alla dagar
            MajTemperatur[] MajDagar = new MajTemperatur[31];

            //loopar igenom alla dagar
            for (int i = 0; i < MajDagar.Length; i++)
            {
                //skapar ny dag för varje loop
                MajDagar[i] = new MajTemperatur((i + 1));

                //skriver ut dag och temperatur
                Console.WriteLine(MajDagar[i].GetTempData());

                Console.WriteLine();
            }
        }

        //räknar ut medeltemperatur
        static void Get_Medel()
        {
            double tempsum = 0;

            MajTemperatur[] MajDagar = new MajTemperatur[31];



            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));

                //plussar in alla dagars temperatur i en variabel

                tempsum += MajDagar[i].Temp;
            }
            //delar summan på 30 för att få medeltemperaturen
            tempsum = tempsum / 30;
            
            Console.WriteLine("Medeltemperaturen är " + Math.Round( tempsum, 2) + " grader");


        } 

        // skapar en metod 
        static void Get_Highest()
        {
            // skapar ett objekt som representerar majdagar 
            MajTemperatur[] MajDagar = new MajTemperatur[31];
            // skapar en array som lagarar tempratur i den nya arrayen sorttemp
            double[] sorttemp = new double[MajDagar.Length];

            // skapar alla dagar i arrayen och lägger in alla tempraturer i sortttemp

            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                sorttemp[i] = MajDagar[i].Temp;

            }
            
            

            // vi sorterar arrayn 

            Array.Sort(sorttemp);




            Console.WriteLine("Högsta uppmätta tempraturen för maj är: "+ sorttemp[30] + " grader");

        }
        static void Get_Lowest()
        {
            // skapar ett objekt som representerar majdagar 

            MajTemperatur[] MajDagar = new MajTemperatur[31];

            // skapar en array som lagarar tempratur i den nya arrayen sorttemp

            double[] sorttemp = new double[MajDagar.Length];


            // skapar alla dagar i arrayen och lägger in alla tempraturer i sortttemp

            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                sorttemp[i] = MajDagar[i].Temp;

            }


            // vi sorterar arrayn 


            Array.Sort(sorttemp);




            Console.WriteLine("Lägsta  uppmätta tempraturen för maj är: "+ sorttemp[0] + " grader");

        }
        static void Get_Median()
        {
            // skapar ett objekt som representerar majdagar 

            MajTemperatur[] MajDagar = new MajTemperatur[31];

            // skapar en array som lagarar tempratur i den nya arrayen sorttemp

            double[] sorttemp = new double[MajDagar.Length];


            // skapar alla dagar i arrayen och lägger in alla tempraturer i sortttemp

            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                sorttemp[i] = MajDagar[i].Temp;

            }



            // vi sorterar arrayn 

            Array.Sort(sorttemp);




            Console.WriteLine(" Mediantempraturen för maj är "+sorttemp[15] + " grader");

        }
        
        static void Risinglist()
        {
            // samma kommentarer som i funktioner ovan 
            MajTemperatur[] MajDagar = new MajTemperatur[31];
            double[] sorttemp = new double[MajDagar.Length];



            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                sorttemp[i] = MajDagar[i].Temp;

            }




            Array.Sort(sorttemp);

            Console.WriteLine("Alla tremperaturer i stigande ordning:");

            for (int i = 0; i < sorttemp.Length; i++)
            {
                Console.WriteLine(sorttemp[i] + " grader");
            }
            

        }
        //skapar en metod/ funktion
        static void Fallinglist()
        {
            // samma kommentarer som i funktioner ovan 

            MajTemperatur[] MajDagar = new MajTemperatur[31];
            double[] sorttemp = new double[MajDagar.Length];



            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                sorttemp[i] = MajDagar[i].Temp;

            }


            Array.Sort(sorttemp);

            Console.WriteLine("Alla tremperaturer i fallande ordning:");
            for (int i = 30; i >= 0; i--)
            {
                Console.WriteLine(sorttemp[i] + " grader");
            }


        }
        // skapar en metod , usertemp är en ny variebalen som skickas från main 
        static void Choosetemp(double usertemp)
        {
            MajTemperatur[] MajDagar = new MajTemperatur[31];

            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                // om tempraturen är lika med användarens valda tempratur eller högre så skriver den ut 
                if (MajDagar[i].Temp >= usertemp)
                {

                    Console.WriteLine( MajDagar[i].GetTempData());

                    Console.WriteLine();
                }
            }
        }

        // samma kommentarer som i funktioner ovan

        static void Multiday(int userday)
        {
            MajTemperatur[] MajDagar = new MajTemperatur[31];

            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));

                
            }
            // en loop som går genom alla dagar, 
            for (int i = 0; i < MajDagar.Length; i++)
            {
                // när den kommer till dagen användaren valde då visas den också dagen innan och dagen efter 
                if (MajDagar[i].Dag == userday)
                {
                    // skriver ut till användaren beronade på vad väljer  -1 är för index som representerar dagen samma sak för för +1
                    Console.WriteLine( MajDagar[i - 1].GetTempData());
                    Console.WriteLine( MajDagar[i].GetTempData());
                    Console.WriteLine(MajDagar[i + 1].GetTempData());

                    Console.WriteLine();
                }
            }
        }

        static void Get_Common()
        {
            MajTemperatur[] MajDagar = new MajTemperatur[31];
            double[] sorttemp = new double[MajDagar.Length];



            for (int i = 0; i < MajDagar.Length; i++)
            {
                MajDagar[i] = new MajTemperatur((i + 1));
                sorttemp[i] = MajDagar[i].Temp;

            }

            //  från sorttemp får man  de mest vanligaste siffrorna 
            var mostCommon = GetMostCommonNumbers(sorttemp);

            // skriver ut vanligaste siffrorna som representerar tempratur 
            foreach (var number in mostCommon)
            {
                Console.WriteLine($"Grader: {number.Key}, Frekvens: {number.Value}");
            }

        }
        static Dictionary<double, int> GetMostCommonNumbers(double[] numbers)
        {
            //  vi skapar en dictionary som lagrar frekvens för varje siffra 
            var frequencyMap = new Dictionary<double, int>();

            // räknar ut frekvensen för varje nummer i arrayen 
            foreach (var number in numbers)
            {
                if (frequencyMap.ContainsKey(number))
                {
                    frequencyMap[number]++;
                }
                else
                {
                    frequencyMap[number] = 1;
                }
            }

            //  sortera alla siffror i fallande ordning 
            var sortedByFrequency = frequencyMap.OrderByDescending(kvp => kvp.Value).ToList();

            // om man vill få det vanligaste värde (ifall det blir oavgjort, då skriver den ut värde ovan)
            return sortedByFrequency.Take(1).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
        }



    }
}
