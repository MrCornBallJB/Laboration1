﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb_3
{

    // skapar en klass som kommer representera dagar i maj
    internal class MajTemperatur
    {
        public double Temp;
        public int Dag;
        
        
        
        // en konstarktur där vi skickar med parameter (type int) och kallar metod random temp
        public MajTemperatur( int dag  )
        {
              this.Dag = dag; 

            Randomtemp();
        }
        // skapar en metod som representerar random tempratur som börjar från 5- 20 
        public void Randomtemp()
        {
            Random random = new Random();
            double Temp = random.NextDouble() * (20 - 5) + 5;
            Temp = Math.Round(Temp, 1);

            
            this.Temp = Temp;
            

            



        }
        // en metod som retunerar en sträng som skriver ut dag och tempratur type int type double 
        public string GetTempData()
        {
            return $"Dag: {Dag} - Temp:  {Temp}";
        }

        
    }
}
